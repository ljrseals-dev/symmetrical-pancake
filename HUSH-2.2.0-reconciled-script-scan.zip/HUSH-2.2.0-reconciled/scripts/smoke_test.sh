#!/bin/bash
# End-to-end CLI smoke test. Usage: scripts/smoke_test.sh path/to/hush
set -u
FK="${1:?path to hush binary}"
T=$(mktemp -d); trap 'rm -rf "$T"' EXIT
pass=0; fail=0
ok(){ if [ "$1" = 0 ]; then pass=$((pass+1)); echo "[ ok ] $2"; else fail=$((fail+1)); echo "[FAIL] $2"; fi; }
expect_fail(){ "$@" >/dev/null 2>&1; [ $? -ne 0 ]; }
"$FK" tone $T/a.wav 20 330 0.2 48000 1 >/dev/null; ok $? "tone generation"
"$FK" info $T/a.wav | grep -q "sample_rate=48000"; ok $? "info reads WAV"
"$FK" forensics $T/a.wav --report $T/rep.txt | grep -q "Limitations"; ok $? "forensics prints limitations"
[ -f $T/rep.txt ] && grep -q file_sha256 $T/rep.txt; ok $? "report written only on request, includes hash"
expect_fail "$FK" forensics $T/a.wav --report $T/rep.txt; ok $? "report refuses to overwrite existing file"
expect_fail "$FK" wm-embed $T/a.wav $T/w.wav --key 7 --payload 10110010; ok $? "wm-embed refuses without --confirm"
[ ! -e $T/w.wav ]; ok $? "no output file created without --confirm"
printf 'preserve this label\n' > $T/blocked.wav.fkwm.txt
expect_fail "$FK" wm-embed $T/a.wav $T/blocked.wav --key 7 --payload 1011 --confirm; ok $? "wm-embed refuses an existing sidecar label"
[ ! -e $T/blocked.wav ] && grep -q 'preserve this label' $T/blocked.wav.fkwm.txt; ok $? "sidecar refusal leaves audio output absent and label untouched"
expect_fail "$FK" wm-embed $T/a.wav $T/a.wav --key 7 --payload 1011 --confirm --overwrite; ok $? "wm-embed refuses to overwrite its own input"
"$FK" wm-embed $T/a.wav $T/w.wav --key 7 --payload 10110010 --confirm >/dev/null; ok $? "wm-embed with --confirm"
[ -f $T/w.wav.fkwm.txt ] && grep -q "WATERMARKED" $T/w.wav.fkwm.txt && ! grep -q "key=7" $T/w.wav.fkwm.txt; ok $? "output labelled; key not written to label"
"$FK" wm-detect $T/w.wav --key 7 --bits 8 | grep -q "signature-like residual detected"; ok $? "wm-detect finds it with the right key"
"$FK" wm-detect $T/w.wav --key 8 --bits 8 | grep -q "no signature detected"; ok $? "wm-detect negative with wrong key"
"$FK" wm-detect $T/a.wav --key 7 --bits 8 | grep -q "no signature detected"; ok $? "wm-detect negative on the original"
cmp -s $T/a.wav $T/a.wav && [ "$(sha256sum < $T/a.wav)" = "$("$FK" tone $T/b.wav 20 330 0.2 48000 1 >/dev/null; sha256sum < $T/b.wav)" ]; ok $? "original unchanged (tone regeneration is byte-identical)"
"$FK" session-new $T/s.fks 48000 120 >/dev/null && "$FK" session-add-track $T/s.fks "Lead vox" >/dev/null && "$FK" session-add-clip $T/s.fks 0 a.wav 0 >/dev/null && "$FK" session-gain $T/s.fks 0 -6 >/dev/null; ok $? "session build commands"
"$FK" session-render $T/s.fks $T/mix.wav | grep -q "frames=960000"; ok $? "session render (relative clip path)"
expect_fail "$FK" session-render $T/s.fks $T/mix.wav; ok $? "render refuses to overwrite without --overwrite"
E=$T/edits.fks
"$FK" session-new $E 48000 120 >/dev/null && "$FK" session-add-track $E Edit >/dev/null && "$FK" session-add-clip $E 0 a.wav 0 >/dev/null && "$FK" session-trim-clip $E 0 0 0 48000 >/dev/null && "$FK" session-fades $E 0 0 100 100 >/dev/null && "$FK" session-move-clip $E 0 0 240 >/dev/null && "$FK" session-split-clip $E 0 0 24000 >/dev/null; ok $? "CLI trim/fade/move/split edits"
"$FK" session-info $E | grep -q "clips=2"; ok $? "session edit commands persist v2 clip metadata"
printf 'FKSESSION 1\nsample_rate 48000\nbpm 9999\n' > $T/bad.fks; expect_fail "$FK" session-info $T/bad.fks; ok $? "malformed session fails with an error"
"$FK" bbt 120 4 4 4 | grep -q "2|1|0  seconds=2"; ok $? "bbt conversion"
"$FK" timecode 1800 29.97df | grep -q "00:01:00;02"; ok $? "drop-frame timecode"
printf 'password = hunter2hunter2\n' > $T/t.txt; out=$("$FK" sensitive-check $T/t.txt); echo "$out" | grep -q "password" && ! echo "$out" | grep -q hunter2; ok $? "sensitive-check reports kind, never the secret"
"$FK" codec-scan | grep -q "not proof\|no devices"; ok $? "codec-scan runs only when invoked"
expect_fail "$FK" bogus-command; ok $? "unknown command fails"
"$FK" selfcheck | grep -q "Informational only"; ok $? "selfcheck is read-only and informational"
expect_fail "$FK" tone $T/a.wav 1 440; ok $? "tone refuses to overwrite an existing file"
expect_fail "$FK" gain $T/a.wav $T/a.wav -6; ok $? "gain refuses output equal to input"
expect_fail "$FK" tone "$T/sub/../x.wav" 1 440; ok $? "output path containing '..' is refused"
ln -s $T/a.wav $T/link.wav; expect_fail "$FK" tone $T/link.wav 1 440 --overwrite; ok $? "refuses to write through a symlink"
"$FK" tone $T/a.wav 1 440 0.2 48000 1 --overwrite >/dev/null; ok $? "--overwrite works when explicitly given"
S=$T/lanes.fks
"$FK" session-new $S 48000 120 >/dev/null && "$FK" session-add-track $S Vox >/dev/null && "$FK" session-add-clip $S 0 a.wav 0 >/dev/null; ok $? "lane session setup"
"$FK" lane-mode $S 0 touch/latch | grep -q "touch/latch"; ok $? "lane-mode accepts touch/latch"
expect_fail "$FK" lane-mode $S 0 sideways; ok $? "lane-mode rejects an unknown mode"
"$FK" lane-point $S 0 volume 0 0 >/dev/null && "$FK" lane-point $S 0 volume 48000 -12 >/dev/null && "$FK" lane-point $S 0 plugin:a:threshold 100 -18.5 >/dev/null && "$FK" lane-point $S 0 send_b_level 10 -3 >/dev/null; ok $? "breakpoints on volume, plugin parameter and send lanes"
expect_fail "$FK" lane-point $S 0 bogus 0 0; ok $? "lane-point rejects an unknown parameter id"
"$FK" lane-show $S 0 | grep -q "plugin:a:threshold"; ok $? "lane-show lists lanes"
"$FK" lane-show $S 0 --param volume | grep -q "48000 -12"; ok $? "lane-show --param prints breakpoints"
printf 'begin 0\nu 1000 -20 1\nu 2000 -20 1\nu 2100 -20 0\nend 5000\n' > $T/ev.txt
"$FK" lane-mode $S 0 touch >/dev/null; "$FK" lane-record $S 0 send_b_level $T/ev.txt | grep -q "replayed 3 control events in mode touch"; ok $? "lane-record replays a Touch pass"
"$FK" lane-show $S 0 --param send_b_level | grep -q "1000 -20"; ok $? "touched span was written to the send lane"
printf 'begin 100\nu 50 0 1\n' > $T/bad_ev.txt; expect_fail "$FK" lane-record $S 0 send_b_level $T/bad_ev.txt; ok $? "lane-record rejects events that go back in time"
"$FK" lane-range $S 0 volume 96000 144000 -30 >/dev/null; ok $? "lane-range writes a constant range"
"$FK" lane-thin $S 0 volume 0.01 | grep -q "removed"; ok $? "lane-thin"
"$FK" session-render $S $T/auto_mix.wav | grep -q "frames=48000"; ok $? "render with automation lanes (a.wav was regenerated as 1 s earlier in this script)"
"$FK" marker-add $S Verse 48000 >/dev/null && "$FK" marker-add $S Solo 96000 --kind selection --end 192000 >/dev/null; ok $? "marker-add (marker and selection)"
expect_fail "$FK" marker-add $S Dup 5 --number 1; ok $? "marker-add rejects a duplicate number"
expect_fail "$FK" marker-add $S Bad 100 --kind selection --end 50; ok $? "marker-add rejects a backwards selection"
"$FK" marker-list $S | grep -q "Solo"; ok $? "marker-list"
"$FK" marker-next $S 0 | grep -q "Verse"; ok $? "marker-next"
"$FK" marker-prev $S 150000 | grep -q "Solo"; ok $? "marker-prev"
"$FK" marker-recall $S 2 | grep -q "end=192000"; ok $? "marker-recall returns the stored range"
"$FK" marker-remove $S 1 >/dev/null && ! "$FK" marker-recall $S 1 >/dev/null 2>&1; ok $? "marker-remove"
"$FK" session-info $S | grep -q "tracks=1"; ok $? "session with lanes and markers reloads"
"$FK" counter 2932800 --sr 48000 --bpm 120 --fps 30 | grep -q "00:01:01:03 .* 31|3|192 .* 0:01:01.100"; ok $? "big counter shows timecode, bars|beats, min:sec and samples"
expect_fail "$FK" counter 100 --fps 12; ok $? "counter rejects an unsupported frame rate"
SC=$T/scan; mkdir -p $SC/sub
printf 'import subprocess\nsubprocess.run(["ls"])\nu = "https://evil.example/x"\n' > $SC/a.py
printf 'os.execute("ls")\nreaper.SetExtState("a","b","c",true)\n' > $SC/sub/s.lua
printf 'echo hi\n' > $SC/ok.sh
"$FK" script-scan $SC | grep -q "py-subprocess"; ok $? "script-scan finds a Python subprocess call"
"$FK" script-scan $SC | grep -q "lua-os-execute"; ok $? "script-scan finds Lua os.execute"
"$FK" script-scan $SC | grep -q "reaper-extstate-persist"; ok $? "script-scan finds a persistent REAPER ExtState write"
"$FK" script-scan $SC --json | grep -q '"requires_human_review": true'; ok $? "script-scan --json output"
"$FK" script-scan $SC --report $T/scan.txt | grep -q "report written"; ok $? "script-scan --report writes a file on request"
expect_fail "$FK" script-scan $SC --report $T/scan.txt; ok $? "script-scan --report refuses to overwrite"
expect_fail "$FK" script-scan $SC --fail-on high; ok $? "script-scan --fail-on high exits non-zero when there are High findings"
"$FK" script-scan $SC/ok.sh --fail-on high >/dev/null; ok $? "script-scan --fail-on passes a clean file"
"$FK" script-scan $SC --allow-host evil.example | grep -q "url-host"; [ $? -ne 0 ]; ok $? "script-scan --allow-host suppresses that host"
(cd $SC && find . -type f | sort | xargs sha256sum) > $T/base.txt
"$FK" script-scan $SC --baseline $T/base.txt --json | grep -q '"modified_files": \[\]'; ok $? "baseline: unchanged tree matches"
printf 'tampered\n' > $SC/ok.sh
"$FK" script-scan $SC --baseline $T/base.txt --json | grep -q '"modified_files": \["ok.sh"\]'; ok $? "baseline: a modified file is reported"
ln -s $SC $T/scanlink; expect_fail "$FK" script-scan $T/scanlink; ok $? "script-scan refuses a symlink root"
expect_fail "$FK" script-scan $T/does-not-exist; ok $? "script-scan reports a missing path"
echo "smoke: $pass passed, $fail failed"; [ $fail -eq 0 ]
