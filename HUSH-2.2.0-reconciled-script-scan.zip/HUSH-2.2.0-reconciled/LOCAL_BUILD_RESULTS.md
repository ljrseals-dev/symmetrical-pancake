# Local build results for HUSH 2.2.0 reconciled source

- Date: 2026-10-14 UTC
- Host: Linux x86-64
- CMake: 3.31.6
- Compiler: GNU C++ 14.2.0
- Configuration: Release; warnings as errors; system PortAudio found; optional X11 GUI found
- Build: PASS (all targets reached 100%)
- Fast tests: 6/6 PASS; 0 failures
- CLI help: PASS
- `hush_detector_calibration`: excluded from the fast gate by project policy; no new pass claimed here
- Hardware input/output, latency, recording, and monitoring: not physically verified

See `evidence/release_gate/run.log`, `evidence/release_gate/ctest.log`, and `evidence/release_gate/cli-help.txt` for captured evidence. The source audit is advisory only, not a security certification.
