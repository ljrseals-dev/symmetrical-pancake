# `hush script-scan`: local script and project scanner (added after 2.1.0)

Read-only, offline, no model needed. It reads files as text and applies fixed rules. It never executes, imports, extracts or fetches anything, never contacts a URL it finds, and skips symbolic links. It writes a file only when you pass `--report` (atomic, refuses to overwrite without `--overwrite`).

## Usage
```
hush script-scan PATH [--json] [--report OUT [--overwrite]] [--baseline SHA256SUMS] [--allow-host HOST]... [--fail-on low|medium|high|critical]
```
`PATH` is a file or a folder (up to 5,000 files, 8 levels deep, 5 MiB per file; larger files are hashed, not scanned). `--fail-on` makes the exit code 3 when a finding at or above that level exists, for use in CI. `--baseline` takes a `sha256sum`-style file and reports modified, new and missing files. `--allow-host` silences URLs to that host and its subdomains.

## What it reads
| Kind | Detected by | Checked for |
|---|---|---|
| Python | `.py .pyw .pyi`, shebang | subprocess / os.system / popen / exec, eval, `__import__`, pickle/marshal, ctypes, socket / urllib / http / requests / ftplib / smtplib / telnetlib / websocket / paramiko, delete and write-mode `open()`, decode-then-execute |
| Lua, EEL | `.lua .eel` | os.execute, io.popen, load / loadstring / dofile / loadfile, package.loadlib / cpath, luasocket, delete / rename / write-mode `io.open` |
| REAPER scripts (Lua/EEL/Python) | same | `ExecProcess` (incl. Python `RPR_ExecProcess`), SWS `CF_ShellExecute`, `AddRemoveReaScript`, persistent `SetExtState(..., true)`, `js_ReaScriptAPI` memory calls, `reaper.defer` loops, `__startup.*` file names |
| JSFX | `.jsfx`, `desc:` header | file access |
| REAPER project / actions | `.RPP`, `reaper-kb.ini` | plugin inventory (`<VST`, `<CLAP`, `<JS`, `<AU`), media paths outside the project, plugin-state blobs counted (not analyzed), registered scripts and custom actions |
| Shell, batch, PowerShell | `.sh .bash .bat .cmd .ps1`, Makefile, Dockerfile | curl / wget, pipe into sh, `/dev/tcp`, `nc -e`, rm -rf, Invoke-Expression / iex, `-EncodedCommand`, DownloadString / DownloadFile, certutil, bitsadmin, reg add, schtasks |
| JavaScript, C/C++ | `.js .mjs .ts`, `.c .cpp .h ...` | child_process, eval, fetch / XHR / WebSocket; system, popen, exec*, dlopen, LoadLibrary, socket |
| Any text or config | everything else | URLs (cleartext, IP literals, `.onion`), secrets by kind (values redacted), long base64 / hex blobs, `\x` escape floods, very long lines, persistence keywords (cron, systemd, launchd, Run key, authorized_keys) |
| Binaries, archives | magic bytes | hashed and listed only; native plugin files (`.vst3 .clap .dll .so .dylib ...`) are inventoried as "not analyzed"; archives are not opened |
UTF-16 files with a byte-order mark are read as their ASCII subset.

## Limits (read these)
- Pattern matching: expect false positives (a legitimate `os.system` call) and false negatives. Heavy obfuscation, string building and indirection defeat it.
- Comments and Python docstrings are skipped for code rules by a simple parser, not a full language parser.
- No data-flow analysis. It cannot tell whether a command line is constant or attacker-controlled.
- Compiled code and archives are never analyzed. Use the hashes and your plugin allowlist.
- REAPER API names come from my knowledge of ReaScript; check them against your REAPER version.
- Output severities and confidence numbers are rule defaults, not measured probabilities.

Self-scan note: scanning HUSH's own tree reports High findings in `src/script_scan.cpp`, `tests/script_scan_tests.cpp` and `SCRIPT_SCAN_NOTES.md` (they contain the patterns as data), in the smoke test's `rm -rf` cleanup, and in the `optional/` installers (genuine). All were reviewed; none is unexpected. Treat scans of security documents and rule tables the same way.

## Evidence
`tests/script_scan_tests.cpp` (55 checks), 13 CLI steps in `scripts/smoke_test.sh`; outputs in `evidence/script_scan/`.
