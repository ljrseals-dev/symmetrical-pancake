# HUSH 2.2.0 feature check: what is missing for a usable DAW

Answer to "does HUSH have a Record button?": **2.1.0 did not; 2.2.0 has a visible Record / Stop Rec control** in the X11 transport (`src/gui_x11.cpp`) and an opt-in PortAudio duplex capture path (`start_recording` / `stop_recording` in `src/portaudio_backend.*`: bounded preallocated buffer, no allocation or disk I/O in the callback, PCM16 WAV written after stop, 5-minute GUI cap, unique take names). What is **not** there: any test of the capture path (no test calls `start_recording`; it needs a device), hardware validation, track arm, punch, pre/post-roll, input monitoring through a channel strip, a device chooser, hot-plug recovery, autosave/crash recovery, loop takes/comping. In my environment PortAudio is not installed, so the capture path was not even compiled in; I confirmed only that the GUI builds and launches under a virtual X server.

Status was checked against the source and HUSH's own documents (grep of `src/`, `src/gui_x11.cpp`, README, PORTING_STATUS) and the SoundCraft README feature list you pasted as the reference set. "Done" means present and tested in HUSH 2.1.0. Priorities use your Early Release format (P0 blockers, P1 essential for a first usable release, P2 important, P3 future).

| Priority | Feature | HUSH 2.1.0 | Notes |
|---|---|---|---|
| P0 | Audio output AND capture proven on real hardware | Not verified | PortAudio backend never exercised with a device; opt-in build |
| P0 | Session save/crash safety | Partial | atomic saves done; no autosave or crash recovery |
| P1 | Recording: arm, punch, pre/post-roll, input monitoring, take management | Partial (2.2.0) | Record/Stop Rec button + duplex capture + WAV take exist; no hardware validation, no unit test of capture, no arm/punch/monitoring |
| P1 | Audio device and buffer-size chooser, hot-plug recovery | Missing | default output device only |
| P1 | Clip editing in the GUI (select, drag, split, trim, fades) | Missing in GUI | move/trim/split/fade exist as library and CLI commands only |
| P1 | Undo for all edits in the GUI | Partial | gain/mute only |
| P1 | Timeline zoom and scroll | Missing | |
| P1 | Loop and punch ranges | Missing | |
| P1 | Export / bounce from the GUI | Missing | `session-render` works from the CLI (WAV only) |
| P1 | Solo, pan | Missing | pan lanes stored but no panner; no solo |
| P1 | MIDI hardware I/O and MIDI editor | Missing | event queue only |
| P1 | Plugin hosting (VST3 / CLAP / AU) | Missing | in-process DSP interface only; policy and sandboxing undecided |
| P1 | Markers, memory locations, big counter in the GUI | Library/CLI only | `marker-*`, `counter` exist; no panels |
| P1 | Automation in the GUI, live Write/Touch/Latch from faders | Library/CLI only | state machine tested; nothing feeds it live; only volume and mute lanes render |
| P1 | Metronome / click, tempo-map editor | Missing | tempo map is a library, constant BPM in CLI |
| P2 | Sends, aux busses, master bus, VCAs, groups | Missing | send lanes stored, nothing to send to |
| P2 | Audio formats beyond WAV (FLAC, AIFF, MP3, Ogg) | Missing | WAV in; PCM16 WAV out |
| P2 | Bounce options: bit depth, dither, normalize, LUFS / true-peak report | Missing | no dither, no loudness |
| P2 | Windows and macOS GUI and builds | Missing | Linux/X11 only |
| P2 | Accessibility pass, keyboard-only use, translations | Missing | |
| P2 | Real-world calibration and independent security review | Open | synthetic corpus only |
| P3 | Playlists and comping, elastic audio / time-stretch, Beat Detective | Missing | |
| P3 | Surround / immersive, video track, score editor, AudioSuite offline plugins | Missing | |
| P3 | Built-in synths and effects (EQ, compressor, reverb ...) | Missing | one test-only gain plugin |
| Done | Offline-first design, no network / telemetry, safe file output | Done | tested |
| Done | WAV in/out, offline render with gain, mute, trim, fades, volume/mute automation | Done | |
| Done | Real-time mixer core, transport, peak meter | Done | callback allocation-free by design; tested |
| Done | Session model, v1/v2 files, undo/redo API | Done | |
| Done | Automation lanes, markers, big-counter formatter | Done (data/CLI) | translated from SoundCraft's model |
| Done | Forensics, watermark, MSV engine (hardened fork) | Done | indicators, synthetic calibration |
| Done | Local script/project scanner (`script-scan`) | Done | this change |
Not in the SoundCraft README list but worth deciding: the SoundCraft MCP / control-channel and its `soundcraft-automation` crate. HUSH's spec excludes remote control, so they are deliberately not wanted.

Suggested order for the next release: (1) device chooser + hardware playback and capture test, (2) arm/punch/pre-roll + input monitoring and a unit test for the capture buffer logic, (3) GUI clip editing + zoom/scroll + loop, (4) solo/pan/bounce from the GUI, (5) autosave/recovery, then MIDI I/O and the plugin-hosting decision.
