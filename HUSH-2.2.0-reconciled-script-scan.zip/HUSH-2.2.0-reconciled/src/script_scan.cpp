#include "script_scan.hpp"
#include <algorithm>
#include <cctype>
#include <cstring>
#include <cstdio>
#include <fstream>
#include <map>
#include <set>
#include <sstream>
#include "clipboard.hpp"
#include "hash.hpp"
namespace fk::scan {
namespace fs = std::filesystem;
const char* severity_name(Severity s) {
  switch (s) { case Severity::Info: return "info"; case Severity::Low: return "low"; case Severity::Medium: return "medium";
               case Severity::High: return "high"; case Severity::Critical: return "critical"; }
  return "info";
}
namespace {
enum Lang : unsigned { PY = 1, LUA = 2, EEL = 4, JSFX = 8, SH = 16, BAT = 32, PS = 64, JS = 128, CC = 256, RPP = 512, CFG = 1024, OTHER = 2048, KB = 4096 };
constexpr unsigned ALL = 0xFFFF, CODE = PY | LUA | EEL | JSFX | SH | BAT | PS | JS | CC;
constexpr unsigned LUALIKE = LUA | EEL | PY;      // REAPER scripting languages
constexpr unsigned SHELLISH = SH | BAT | PS;
enum Flag : unsigned { NONE = 0, NOT_AFTER_DOT = 1, NO_BOUNDARY = 2 };   // NO_BOUNDARY: also match inside RPR_ExecProcess-style names
struct Rule {
  const char* id; unsigned langs; const char* needle; unsigned flags; Severity sev; const char* topic; const char* category;
  const char* title; const char* why; double conf, fp;
};
using S = Severity;
const Rule kRules[] = {
  // ---- process execution ----
  {"py-subprocess", PY, "subprocess.", NONE, S::Medium, "process_exec", "backdoor", "subprocess use", "runs external programs; check the command line and who controls it", .6, .4},
  {"py-os-system", PY, "os.system(", NONE, S::High, "process_exec", "backdoor", "os.system call", "runs a shell command", .8, .25},
  {"py-os-popen", PY, "os.popen(", NONE, S::High, "process_exec", "backdoor", "os.popen call", "runs a shell command and reads its output", .8, .25},
  {"py-os-exec", PY, "os.exec", NONE, S::High, "process_exec", "backdoor", "os.exec* call", "replaces the process with another program", .8, .25},
  {"py-os-spawn", PY, "os.spawn", NONE, S::Medium, "process_exec", "backdoor", "os.spawn* call", "starts another process", .7, .3},
  {"py-pty-spawn", PY, "pty.spawn", NONE, S::High, "process_exec", "backdoor", "pty.spawn call", "typical of reverse-shell code", .8, .2},
  {"lua-os-execute", LUA, "os.execute", NONE, S::High, "process_exec", "backdoor", "os.execute call", "runs a shell command", .8, .25},
  {"lua-io-popen", LUA, "io.popen", NONE, S::High, "process_exec", "backdoor", "io.popen call", "runs a shell command and reads its output", .8, .25},
  {"reaper-execprocess", LUALIKE, "execprocess(", NO_BOUNDARY, S::High, "process_exec", "reascript_risk", "ReaScript ExecProcess", "runs a command line from inside REAPER; judge the command and whether the user triggered it", .7, .35},
  {"reaper-shellexecute", LUALIKE, "cf_shellexecute", NO_BOUNDARY, S::Medium, "process_exec", "reascript_risk", "SWS CF_ShellExecute", "opens a file or URL with the system handler", .6, .4},
  {"sh-curl", SH, "curl ", NONE, S::Medium, "network", "call_home", "curl invocation", "downloads or uploads over the network", .6, .4},
  {"sh-wget", SH, "wget ", NONE, S::Medium, "network", "call_home", "wget invocation", "downloads over the network", .6, .4},
  {"sh-nc-e", SH, "nc -e", NONE, S::High, "process_exec", "backdoor", "netcat with -e", "classic bind/reverse shell", .9, .1},
  {"sh-dev-tcp", SH, "/dev/tcp/", NONE, S::High, "network", "backdoor", "bash /dev/tcp redirection", "opens a raw TCP connection from the shell; common in reverse shells", .85, .15},
  {"sh-bash-i", SH, "bash -i", NONE, S::High, "process_exec", "backdoor", "interactive bash", "typical of reverse-shell one-liners", .6, .4},
  {"sh-pipe-shell", SH, "| sh", NONE, S::High, "process_exec", "backdoor", "pipe into a shell", "executes whatever the previous command produced", .7, .3},
  {"sh-pipe-bash", SH, "| bash", NONE, S::High, "process_exec", "backdoor", "pipe into bash", "executes whatever the previous command produced", .7, .3},
  {"sh-base64-d", SH, "base64 -d", NONE, S::Medium, "obfuscation", "backdoor", "base64 decode in shell", "decoded content is often executed next", .5, .5},
  {"sh-eval", SH, "eval ", NONE, S::Medium, "dynamic_code", "backdoor", "eval in shell", "executes a constructed string", .5, .5},
  {"sh-mkfifo", SH, "mkfifo", NONE, S::Medium, "process_exec", "backdoor", "named pipe creation", "used in some reverse-shell constructions", .4, .6},
  {"ps-iwr", SHELLISH, "invoke-webrequest", NONE, S::Medium, "network", "call_home", "Invoke-WebRequest", "downloads or uploads over the network", .6, .4},
  {"ps-iex", SHELLISH, "invoke-expression", NONE, S::High, "dynamic_code", "backdoor", "Invoke-Expression", "executes a constructed string", .8, .2},
  {"ps-iex-short", PS | BAT, "iex ", NOT_AFTER_DOT, S::High, "dynamic_code", "backdoor", "iex alias", "executes a constructed string", .6, .4},
  {"ps-enc", SHELLISH, "-encodedcommand", NONE, S::High, "obfuscation", "backdoor", "PowerShell -EncodedCommand", "hides the command in base64", .85, .15},
  {"ps-downloadstring", SHELLISH, "downloadstring", NONE, S::High, "network", "call_home", "DownloadString", "downloads code as text, usually to execute it", .85, .15},
  {"ps-downloadfile", SHELLISH, "downloadfile", NONE, S::High, "network", "call_home", "DownloadFile", "downloads a file", .8, .2},
  {"ps-frombase64", SHELLISH, "frombase64string", NONE, S::Medium, "obfuscation", "backdoor", "FromBase64String", "decodes hidden content", .5, .5},
  {"win-certutil", SHELLISH, "certutil", NONE, S::Medium, "network", "call_home", "certutil", "often abused to download or decode files", .5, .5},
  {"win-bitsadmin", SHELLISH, "bitsadmin", NONE, S::Medium, "network", "call_home", "bitsadmin", "often abused to download files", .6, .4},
  {"win-reg-add", SHELLISH, "reg add", NONE, S::Medium, "persistence", "backdoor", "registry write", "can create startup entries", .5, .5},
  {"win-schtasks", SHELLISH, "schtasks", NONE, S::Medium, "persistence", "backdoor", "scheduled task", "can create persistence", .6, .4},
  {"js-child-process", JS, "child_process", NONE, S::High, "process_exec", "backdoor", "child_process", "runs external programs", .8, .25},
  {"js-eval", JS, "eval(", NOT_AFTER_DOT, S::Medium, "dynamic_code", "backdoor", "eval call", "executes a constructed string", .6, .4},
  {"js-new-function", JS, "new function(", NONE, S::Medium, "dynamic_code", "backdoor", "new Function", "executes a constructed string", .6, .4},
  {"c-system", CC, "system(", NOT_AFTER_DOT, S::High, "process_exec", "backdoor", "system() call", "runs a shell command", .8, .25},
  {"c-popen", CC, "popen(", NOT_AFTER_DOT, S::High, "process_exec", "backdoor", "popen() call", "runs a shell command", .8, .25},
  {"c-exec", CC, "execv", NONE, S::High, "process_exec", "backdoor", "exec* call", "replaces the process", .8, .25},
  {"c-dlopen", CC, "dlopen(", NONE, S::Medium, "dynamic_code", "backdoor", "dlopen", "loads native code at run time", .6, .4},
  {"c-loadlibrary", CC, "loadlibrary", NONE, S::Medium, "dynamic_code", "backdoor", "LoadLibrary", "loads native code at run time", .6, .4},
  {"c-socket", CC, "socket(", NOT_AFTER_DOT, S::Medium, "network", "call_home", "socket()", "opens a network socket", .6, .4},
  // ---- dynamic code ----
  {"py-exec", PY, "exec(", NOT_AFTER_DOT, S::High, "dynamic_code", "backdoor", "exec call", "executes a constructed string", .7, .3},
  {"py-eval", PY, "eval(", NOT_AFTER_DOT, S::High, "dynamic_code", "backdoor", "eval call", "executes a constructed expression", .7, .3},
  {"py-import-dyn", PY, "__import__(", NONE, S::Medium, "dynamic_code", "backdoor", "__import__", "imports a module chosen at run time", .6, .4},
  {"py-pickle", PY, "pickle.loads", NONE, S::High, "dynamic_code", "backdoor", "pickle.loads", "unpickling untrusted data can run code", .7, .3},
  {"py-marshal", PY, "marshal.loads", NONE, S::High, "dynamic_code", "backdoor", "marshal.loads", "loads code objects", .7, .3},
  {"py-ctypes", PY, "ctypes.", NONE, S::Medium, "dynamic_code", "backdoor", "ctypes", "calls native code directly", .6, .4},
  {"lua-loadstring", LUA, "loadstring(", NOT_AFTER_DOT, S::High, "dynamic_code", "backdoor", "loadstring", "executes a constructed string", .8, .2},
  {"lua-load", LUA, "load(", NOT_AFTER_DOT, S::Medium, "dynamic_code", "backdoor", "load", "may execute a constructed string", .5, .5},
  {"lua-dofile", LUA, "dofile(", NOT_AFTER_DOT, S::Medium, "dynamic_code", "backdoor", "dofile", "runs another file", .6, .4},
  {"lua-loadfile", LUA, "loadfile(", NOT_AFTER_DOT, S::Medium, "dynamic_code", "backdoor", "loadfile", "loads another file as code", .6, .4},
  {"lua-loadlib", LUA, "package.loadlib", NONE, S::High, "dynamic_code", "backdoor", "package.loadlib", "loads a native library", .8, .2},
  {"lua-cpath", LUA, "package.cpath", NONE, S::Medium, "dynamic_code", "backdoor", "package.cpath", "changes where native modules are loaded from", .6, .4},
  // ---- network ----
  {"py-socket", PY, "import socket", NONE, S::Medium, "network", "call_home", "socket module", "can open network connections or listeners", .6, .4},
  {"py-socket-from", PY, "from socket", NONE, S::Medium, "network", "call_home", "socket module", "can open network connections or listeners", .6, .4},
  {"py-socketserver", PY, "socketserver", NONE, S::High, "network", "backdoor", "socketserver", "runs a network listener", .7, .3},
  {"py-urllib", PY, "urllib", NONE, S::Medium, "network", "call_home", "urllib", "makes HTTP requests", .6, .4},
  {"py-http-client", PY, "http.client", NONE, S::Medium, "network", "call_home", "http.client", "makes HTTP requests", .6, .4},
  {"py-requests", PY, "import requests", NONE, S::Medium, "network", "call_home", "requests", "makes HTTP requests", .6, .4},
  {"py-httpx", PY, "import httpx", NONE, S::Medium, "network", "call_home", "httpx", "makes HTTP requests", .6, .4},
  {"py-aiohttp", PY, "aiohttp", NONE, S::Medium, "network", "call_home", "aiohttp", "makes HTTP requests", .6, .4},
  {"py-ftplib", PY, "ftplib", NONE, S::Medium, "network", "call_home", "ftplib", "FTP transfers", .6, .4},
  {"py-smtplib", PY, "smtplib", NONE, S::Medium, "network", "exfiltration", "smtplib", "sends e-mail", .6, .4},
  {"py-telnetlib", PY, "telnetlib", NONE, S::High, "network", "backdoor", "telnetlib", "remote shell protocol", .7, .3},
  {"py-websocket", PY | JS, "websocket", NONE, S::Medium, "network", "call_home", "WebSocket", "persistent network channel", .6, .4},
  {"py-paramiko", PY, "paramiko", NONE, S::Medium, "network", "call_home", "paramiko (SSH)", "remote SSH access", .6, .4},
  {"lua-socket", LUA, "socket.", NOT_AFTER_DOT, S::Medium, "network", "call_home", "Lua socket", "network access", .5, .5},
  {"lua-luasocket", LUA, "luasocket", NONE, S::Medium, "network", "call_home", "luasocket", "network access", .6, .4},
  {"js-xhr", JS, "xmlhttprequest", NONE, S::Medium, "network", "call_home", "XMLHttpRequest", "makes HTTP requests", .6, .4},
  {"js-fetch", JS, "fetch(", NOT_AFTER_DOT, S::Medium, "network", "call_home", "fetch", "makes HTTP requests", .5, .5},
  // ---- file writes / destruction ----
  {"py-rmtree", PY, "shutil.rmtree", NONE, S::Medium, "file_write", "other", "recursive delete", "deletes directory trees", .6, .4},
  {"py-os-remove", PY, "os.remove(", NONE, S::Medium, "file_write", "other", "file delete", "deletes files", .5, .5},
  {"py-os-unlink", PY, "os.unlink(", NONE, S::Medium, "file_write", "other", "file delete", "deletes files", .5, .5},
  {"lua-os-remove", LUA, "os.remove(", NONE, S::Medium, "file_write", "other", "file delete", "deletes files", .5, .5},
  {"lua-os-rename", LUA, "os.rename(", NONE, S::Low, "file_write", "other", "file rename", "moves or replaces files", .4, .6},
  {"sh-rm-rf", SH, "rm -rf", NONE, S::High, "file_write", "other", "rm -rf", "recursive forced delete", .7, .3},
  {"sh-dd", SH, "dd if=", NONE, S::High, "file_write", "other", "dd", "raw disk or file overwrite", .7, .3},
  {"sh-mkfs", SH, "mkfs", NONE, S::High, "file_write", "other", "mkfs", "formats a filesystem", .8, .2},
  {"sh-chmod-777", SH, "chmod 777", NONE, S::Medium, "file_write", "other", "chmod 777", "world-writable permissions", .6, .4},
  {"sh-chmod-suid", SH, "chmod +s", NONE, S::High, "persistence", "backdoor", "setuid bit", "privilege escalation vector", .8, .2},
  {"bat-rmdir", BAT, "rmdir /s", NONE, S::High, "file_write", "other", "rmdir /s", "recursive delete", .7, .3},
  // ---- persistence (any language) ----
  {"any-crontab", ALL, "crontab", NONE, S::Medium, "persistence", "backdoor", "cron entry", "can create persistence", .5, .5},
  {"any-systemctl", ALL, "systemctl enable", NONE, S::Medium, "persistence", "backdoor", "systemd enable", "can create persistence", .6, .4},
  {"any-launchctl", ALL, "launchctl", NONE, S::Medium, "persistence", "backdoor", "launchctl", "can create persistence on macOS", .5, .5},
  {"any-launchagents", ALL, "launchagents", NONE, S::Medium, "persistence", "backdoor", "LaunchAgents path", "can create persistence on macOS", .6, .4},
  {"any-run-key", ALL, "currentversion\\run", NONE, S::Medium, "persistence", "backdoor", "Windows Run key", "can create persistence", .7, .3},
  {"any-bashrc", ALL, ".bashrc", NONE, S::Low, "persistence", "backdoor", "shell startup file", "check whether it is written to", .3, .7},
  {"any-rclocal", ALL, "/etc/rc.local", NONE, S::Medium, "persistence", "backdoor", "rc.local", "can create persistence", .6, .4},
  {"any-authkeys", ALL, "authorized_keys", NONE, S::High, "persistence", "backdoor", "authorized_keys", "SSH key injection", .7, .3},
  // ---- REAPER specifics ----
  {"reaper-addremove", LUALIKE, "addremovereascript", NO_BOUNDARY, S::Medium, "persistence", "reascript_risk", "AddRemoveReaScript", "registers actions persistently", .6, .4},
  {"reaper-jsmem", LUALIKE, "js_mem", NO_BOUNDARY, S::Medium, "dynamic_code", "reascript_risk", "js_ReaScriptAPI memory access", "raw memory access gives a script wide reach", .6, .4},
  {"reaper-defer", LUALIKE, "reaper.defer(", NONE, S::Info, "persistence", "reascript_risk", "defer loop", "runs in the background until stopped; check that it terminates", .3, .8},
  {"jsfx-fileopen", JSFX, "file_open(", NONE, S::Low, "file_write", "reascript_risk", "JSFX file access", "unexpected for an audio effect", .5, .5},
  // ---- anti-analysis ----
  {"any-isdebugger", CODE, "isdebuggerpresent", NONE, S::Medium, "anti_analysis", "backdoor", "debugger check", "anti-debugging", .6, .4},
  {"py-gettrace", PY, "sys.gettrace", NONE, S::Low, "anti_analysis", "backdoor", "tracer check", "may detect debuggers", .4, .6},
  {"any-vm-check", CODE, "virtualbox", NONE, S::Low, "anti_analysis", "backdoor", "virtual machine string", "may be an anti-VM check", .3, .7},
  {"any-tracerpid", CODE, "tracerpid", NONE, S::Low, "anti_analysis", "backdoor", "TracerPid check", "may be an anti-debug check", .4, .6},
};

bool ident(char c) { return std::isalnum(static_cast<unsigned char>(c)) || c == '_'; }
std::string lower(std::string s) { for (auto& c : s) c = static_cast<char>(std::tolower(static_cast<unsigned char>(c))); return s; }
bool ends_with(const std::string& s, const std::string& e) { return s.size() >= e.size() && s.compare(s.size() - e.size(), e.size(), e) == 0; }

unsigned lang_bit(const std::string& l) {
  static const std::map<std::string, unsigned> m = {{"python", PY}, {"lua", LUA}, {"eel", EEL}, {"jsfx", JSFX}, {"shell", SH}, {"batch", BAT},
    {"powershell", PS}, {"javascript", JS}, {"c/c++", CC}, {"reaper-project", RPP}, {"config", CFG}, {"text", OTHER}, {"reaper-actions", KB}};
  auto it = m.find(l); return it == m.end() ? OTHER : it->second;
}
std::string trim(const std::string& s) {
  std::size_t a = 0, b = s.size();
  while (a < b && std::isspace(static_cast<unsigned char>(s[a]))) ++a;
  while (b > a && std::isspace(static_cast<unsigned char>(s[b - 1]))) --b;
  return s.substr(a, b - a);
}
std::string clip(const std::string& s, std::size_t n = 120) {
  std::string t = trim(s);
  if (t.size() > n) t = t.substr(0, n) + "...";
  for (auto& c : t) if (static_cast<unsigned char>(c) < 32 && c != '\t') c = ' ';
  return t;
}
// Splits a line into code and comment parts (best effort; tracks block comments and triple-quoted strings).
struct LineState { bool block_comment = false; bool triple = false; char triple_q = 0; bool lua_block = false; };
void split_comment(const std::string& line, unsigned lang, LineState& st, std::string& code, std::string& comment) {
  code.clear(); comment.clear();
  const bool hash_c = lang & (PY | SH | PS | CFG | OTHER);
  const bool slash_c = lang & (JS | CC | EEL | JSFX);
  const bool dash_c = lang & LUA;
  char q = 0;
  for (std::size_t i = 0; i < line.size(); ++i) {
    char c = line[i];
    if (st.block_comment) { comment.push_back(c); if (c == '*' && i + 1 < line.size() && line[i + 1] == '/') { st.block_comment = false; comment.push_back('/'); ++i; } continue; }
    if (st.lua_block) { comment.push_back(c); if (c == ']' && i + 1 < line.size() && line[i + 1] == ']') { st.lua_block = false; comment.push_back(']'); ++i; } continue; }
    if (st.triple) {   // inside a Python triple-quoted string: treat as comment text
      comment.push_back(c);
      if (c == st.triple_q && i + 2 < line.size() + 0 && line.compare(i, 3, std::string(3, st.triple_q)) == 0) { st.triple = false; comment += std::string(2, st.triple_q); i += 2; }
      continue;
    }
    if (q) { code.push_back(c); if (c == '\\' && i + 1 < line.size()) { code.push_back(line[++i]); } else if (c == q) q = 0; continue; }
    if ((lang & PY) && (c == '"' || c == '\'') && line.compare(i, 3, std::string(3, c)) == 0) { st.triple = true; st.triple_q = c; i += 2; continue; }
    if (c == '"' || c == '\'') { q = c; code.push_back(c); continue; }
    if (slash_c && c == '/' && i + 1 < line.size() && line[i + 1] == '/') { comment = line.substr(i); return; }
    if (slash_c && c == '/' && i + 1 < line.size() && line[i + 1] == '*') { st.block_comment = true; comment.push_back('/'); continue; }
    if (dash_c && c == '-' && i + 1 < line.size() && line[i + 1] == '-') {
      if (line.compare(i, 4, "--[[") == 0) { st.lua_block = true; comment = line.substr(i); return; }
      comment = line.substr(i); return;
    }
    if (hash_c && c == '#') { comment = line.substr(i); return; }
    if ((lang & PS) && c == '<' && line.compare(i, 2, "<#") == 0) { comment = line.substr(i); return; }
    code.push_back(c);
  }
  if (lang & BAT) { std::string t = lower(trim(code)); if (t.rfind("rem ", 0) == 0 || t.rfind("::", 0) == 0) { comment = code; code.clear(); } }
}
bool has_write_mode(const std::string& after_open) {
  const std::size_t end = std::min<std::size_t>(after_open.size(), 120);
  for (std::size_t i = 0; i + 2 < end; ++i) {
    char q = after_open[i];
    if (q != '"' && q != '\'') continue;
    std::size_t j = i + 1;
    if (j < end && (after_open[j] == 'w' || after_open[j] == 'a' || after_open[j] == 'x')) {
      ++j; while (j < end && (after_open[j] == '+' || after_open[j] == 'b' || after_open[j] == 't')) ++j;
      if (j < end && after_open[j] == q) return true;
    }
  }
  return false;
}
bool is_local_host(const std::string& h) {
  return h == "localhost" || h == "::1" || h == "[::1]" || h.rfind("127.", 0) == 0 || h == "0.0.0.0";
}
bool parse_ipv4(const std::string& h) {
  int parts = 0; std::size_t i = 0;
  while (i < h.size()) {
    std::size_t j = i; int v = 0;
    while (j < h.size() && std::isdigit(static_cast<unsigned char>(h[j]))) { v = v * 10 + (h[j] - '0'); if (v > 255) return false; ++j; }
    if (j == i) return false;
    ++parts; if (j == h.size()) break;
    if (h[j] != '.') return false;
    i = j + 1;
  }
  return parts == 4;
}
bool host_allowed(const std::string& host, const std::vector<std::string>& allow) {
  for (auto a : allow) { a = lower(a); if (host == a || (host.size() > a.size() && ends_with(host, "." + a))) return true; }
  return false;
}
bool b64ish(char c) { return std::isalnum(static_cast<unsigned char>(c)) || c == '+' || c == '/' || c == '='; }
bool all_b64(const std::string& s) { if (s.empty()) return false; for (char c : s) if (!b64ish(c)) return false; return true; }

struct Ctx {
  const Options& opt; std::string file; unsigned lang; Report& rep;
  Ctx(const Options& o, std::string f, unsigned l, Report& r) : opt(o), file(std::move(f)), lang(l), rep(r) {}
  std::size_t plugin_refs = 0, media_refs = 0, blobs = 0, urls = 0;
  std::size_t decode_line = 0, exec_line = 0;
  std::set<std::string> seen;   // dedupe rule+line
  void add(const char* rule, const char* topic, const char* cat, const std::string& title, Severity sev, std::size_t line, const std::string& ev,
           const std::string& why, double conf, double fp) {
    std::string key = std::string(rule) + ":" + std::to_string(line) + ":" + ev;
    if (!seen.insert(key).second) return;
    Finding f; f.rule = rule; f.topic = topic; f.category = cat; f.title = title; f.severity = sev; f.file = file; f.line = line;
    f.evidence = ev; f.why = why; f.confidence = conf; f.false_positive = fp; rep.findings.push_back(std::move(f));
  }
};

void scan_urls(Ctx& c, const std::string& line, std::size_t ln) {
  const std::string lo = lower(line);
  for (std::size_t p = lo.find("://"); p != std::string::npos; p = lo.find("://", p + 3)) {
    std::size_t s = p; while (s > 0 && std::isalpha(static_cast<unsigned char>(lo[s - 1]))) --s;
    std::string scheme = lo.substr(s, p - s);
    if (scheme != "http" && scheme != "https" && scheme != "ftp" && scheme != "ws" && scheme != "wss" && scheme != "tcp" && scheme != "udp" && scheme != "sftp") continue;
    std::size_t h = p + 3, e = h;
    while (e < lo.size() && !std::strchr("/?#\"' )]>,;\\", lo[e]) && !std::isspace(static_cast<unsigned char>(lo[e]))) ++e;
    std::string host = lo.substr(h, e - h);
    auto at = host.rfind('@'); if (at != std::string::npos) host = host.substr(at + 1);
    if (!host.empty() && host[0] != '[') { auto col = host.find(':'); if (col != std::string::npos) host = host.substr(0, col); }
    if (host.empty() || host.find('{') != std::string::npos || host.find('$') != std::string::npos || host.find('%') != std::string::npos) continue;
    if (is_local_host(host) || host_allowed(host, c.opt.allow_hosts)) continue;
    ++c.urls;
    std::string url = clip(line.substr(s, std::min<std::size_t>(e - s + 40, 160)), 100);
    if (ends_with(host, ".onion") || ends_with(host, ".i2p")) c.add("url-onion", "network", "call_home", "Tor/I2P address", S::High, ln, url, "anonymity-network endpoint", .85, .1);
    else if (parse_ipv4(host)) c.add("url-ip-literal", "network", "call_home", "URL with an IP address", S::Medium, ln, url, "raw IP endpoints bypass DNS-based review; verify it is authorized", .6, .4);
    else if (scheme == "http" || scheme == "ftp" || scheme == "ws") c.add("url-cleartext", "network", "call_home", "Cleartext URL to " + host, S::Medium, ln, url, "unencrypted network endpoint; verify it is authorized", .5, .5);
    else c.add("url-host", "network", "call_home", "URL to " + host, S::Low, ln, url, "verify the host against the authorized endpoints", .4, .6);
  }
}
void scan_generic(Ctx& c, const std::string& line, std::size_t ln) {
  scan_urls(c, line, ln);
  if (line.size() > 8 && line.size() < 4000) {
    for (auto& f : fk::clipboard::scan_sensitive(line))
      if (f.kind != "long opaque token-like string")
        c.add("secret", "secret", "other", "possible secret: " + f.kind, S::Medium, ln, "[redacted]", "credentials in source can leak or act as a hard-coded backdoor credential", .6, .4);
  }
  std::size_t run = 0, best = 0; std::size_t hexrun = 0, hexbest = 0, xcount = 0;
  for (std::size_t i = 0; i < line.size(); ++i) {
    char ch = line[i];
    run = b64ish(ch) ? run + 1 : 0; best = std::max(best, run);
    hexrun = std::isxdigit(static_cast<unsigned char>(ch)) ? hexrun + 1 : 0; hexbest = std::max(hexbest, hexrun);
    if (ch == '\\' && i + 1 < line.size() && (line[i + 1] == 'x' || line[i + 1] == 'u')) ++xcount;
  }
  const bool blob_ok = (c.lang & (RPP | CFG)) && (all_b64(trim(line)) || line.find('=') == std::string::npos);
  if (best >= 120 && !(c.lang & RPP && all_b64(trim(line)))) { ++c.blobs; if (c.lang & RPP) {} else c.add("long-base64", "obfuscation", "backdoor", "long encoded blob", S::Medium, ln, "(" + std::to_string(best) + " base64-like characters)", "encoded payloads are a common way to hide code or data", .5, .5); }
  else if (hexbest >= 96 && !blob_ok) c.add("long-hex", "obfuscation", "backdoor", "long hex string", S::Low, ln, "(" + std::to_string(hexbest) + " hex characters)", "may be an encoded payload (or a hash/key)", .3, .7);
  if (xcount > 40) c.add("escape-heavy", "obfuscation", "backdoor", "heavy \\x / \\u escape sequences", S::Medium, ln, "(" + std::to_string(xcount) + " escapes)", "character escapes are used to hide strings", .5, .5);
  if (line.size() > 5000 && !(c.lang & (RPP | CFG))) c.add("very-long-line", "obfuscation", "backdoor", "very long line (minified or obfuscated?)", S::Low, ln, "(" + std::to_string(line.size()) + " characters)", "hard to review", .3, .7);
}
void apply_rules(Ctx& c, const std::string& code, std::size_t ln, const std::string& full) {
  const std::string lo = lower(code);
  if (lo.empty()) return;
  for (const auto& r : kRules) {
    if (!(r.langs & c.lang)) continue;
    const std::string needle = r.needle;
    for (std::size_t p = lo.find(needle); p != std::string::npos; p = lo.find(needle, p + 1)) {
      if (ident(needle[0]) && !(r.flags & NO_BOUNDARY)) {
        if (p > 0 && ident(lo[p - 1])) continue;
        if ((r.flags & NOT_AFTER_DOT) && p > 0 && lo[p - 1] == '.') continue;
      }
      c.add(r.id, r.topic, r.category, r.title, r.sev, ln, clip(full), r.why, r.conf, r.fp);
      break;
    }
  }
  // write-mode open()
  for (std::size_t p = lo.find("open("); p != std::string::npos; p = lo.find("open(", p + 1)) {
    if (p > 0 && (ident(lo[p - 1]) && lo[p - 1] != '.')) continue;
    const bool lua_io = p >= 3 && lo.compare(p - 3, 3, "io.") == 0;
    if (((c.lang & PY) && (p == 0 || lo[p - 1] != '.' ) ) || ((c.lang & LUA) && lua_io)) {
      if (has_write_mode(code.substr(p))) { c.add("file-write-open", "file_write", "other", "file opened for writing", S::Medium, ln, clip(full), "writes files; check the destination and that the user asked for it", .5, .5); break; }
    }
  }
  // persistent ExtState
  std::size_t es = lo.find("setextstate(");
  if (es != std::string::npos && (c.lang & LUALIKE)) {
    std::string rest = lo.substr(es);
    auto cp = rest.rfind(')'); if (cp != std::string::npos) rest = rest.substr(0, cp);
    auto tp = rest.rfind("true");
    if (tp != std::string::npos && rest.find_first_not_of(" \t", tp + 4) == std::string::npos)
      c.add("reaper-extstate-persist", "persistence", "reascript_risk", "persistent ExtState write", S::Medium, ln, clip(full), "saved to disk and read back across sessions; can hold state or payloads", .5, .5);
  }
  // decode and execute markers (file-level combination)
  static const char* dec[] = {"b64decode", "atob(", "fromhex(", "frombase64string", "base64 -d", "codecs.decode(", "zlib.decompress", "string.char("};
  static const char* exe[] = {"exec(", "eval(", "loadstring(", "load(", "os.system(", "subprocess.", "invoke-expression", "iex ", "os.execute", "execprocess("};
  for (auto d : dec) if (lo.find(d) != std::string::npos && !c.decode_line) c.decode_line = ln;
  for (auto e : exe) { auto p = lo.find(e); if (p != std::string::npos && (p == 0 || !ident(lo[p - 1])) && !c.exec_line) c.exec_line = ln; }
}
void scan_rpp(Ctx& c, const std::string& line, std::size_t ln) {
  std::string t = trim(line);
  static const char* plug[] = {"<vst ", "<vst3 ", "<clap ", "<js ", "<au ", "<dx ", "<vst3i ", "<vsti "};
  std::string lo = lower(t);
  for (auto p : plug) if (lo.rfind(p, 0) == 0) { if (++c.plugin_refs <= 200) c.add("rpp-plugin", "inventory", "unauthorized_plugin", "project references a plugin", S::Info, ln, clip(t, 110), "inventory for the plugin allowlist; confirm each plugin is authorized", .5, .5); return; }
  if (lo.rfind("file ", 0) == 0 || lo.rfind("filename ", 0) == 0) {
    bool abs = t.find(" \"/") != std::string::npos || t.find(" /") != std::string::npos || (t.size() > 8 && t.find(":\\") != std::string::npos) || t.find("..") != std::string::npos;
    if (abs && ++c.media_refs <= 100) c.add("rpp-external-path", "inventory", "other", "media or file path outside the project", S::Low, ln, clip(t, 110), "project depends on a file at an absolute or parent path", .4, .6);
  }
}
void scan_kb(Ctx& c, const std::string& line, std::size_t ln) {
  std::string t = trim(line);
  if (t.rfind("SCR ", 0) == 0) c.add("kb-script", "persistence", "reascript_risk", "registered script action", S::Info, ln, clip(t, 140), "script registered as an action; confirm it is reviewed", .5, .5);
  else if (t.rfind("ACT ", 0) == 0) c.add("kb-custom-action", "inventory", "reascript_risk", "custom action", S::Info, ln, clip(t, 140), "custom action; check what it runs", .4, .6);
}

std::string strip_nuls_for_utf16(const std::string& raw, bool& changed) {
  changed = false;
  if (raw.size() >= 2 && ((static_cast<unsigned char>(raw[0]) == 0xFF && static_cast<unsigned char>(raw[1]) == 0xFE) || (static_cast<unsigned char>(raw[0]) == 0xFE && static_cast<unsigned char>(raw[1]) == 0xFF))) {
    std::string out; for (std::size_t i = 2; i < raw.size(); ++i) if (raw[i] != '\0') out.push_back(raw[i]);
    changed = true; return out;
  }
  return raw;
}
std::string magic_kind(const std::string& raw) {
  auto u = [&](std::size_t i) { return i < raw.size() ? static_cast<unsigned char>(raw[i]) : 0u; };
  if (u(0) == 0x7F && u(1) == 'E' && u(2) == 'L' && u(3) == 'F') return "ELF executable/library";
  if (u(0) == 'M' && u(1) == 'Z') return "Windows PE executable/DLL";
  if ((u(0) == 0xCF && u(1) == 0xFA && u(2) == 0xED && u(3) == 0xFE) || (u(0) == 0xFE && u(1) == 0xED && u(2) == 0xFA) || (u(0) == 0xCA && u(1) == 0xFE && u(2) == 0xBA && u(3) == 0xBE)) return "Mach-O executable/library";
  if (u(0) == 'P' && u(1) == 'K' && u(2) == 3 && u(3) == 4) return "ZIP archive";
  if (u(0) == 0x1F && u(1) == 0x8B) return "gzip archive";
  if (u(0) == '%' && u(1) == 'P' && u(2) == 'D' && u(3) == 'F') return "PDF document";
  return "binary data";
}
void scan_content(Ctx& c, const std::string& text) {
  LineState st; std::size_t ln = 0; std::size_t pos = 0;
  std::string code, comment;
  const unsigned lang = c.lang;
  while (pos <= text.size()) {
    std::size_t e = text.find('\n', pos);
    std::string line = text.substr(pos, e == std::string::npos ? std::string::npos : e - pos);
    if (!line.empty() && line.back() == '\r') line.pop_back();
    ++ln; pos = (e == std::string::npos) ? text.size() + 1 : e + 1;
    if (line.empty()) continue;
    const std::string scan_line = line.size() > 20000 ? line.substr(0, 20000) : line;
    if (lang & RPP) { scan_rpp(c, scan_line, ln); }
    if (lang & KB) { scan_kb(c, scan_line, ln); }
    if (lang & (RPP)) { std::string t = trim(scan_line); if (all_b64(t) && t.size() >= 40) { ++c.blobs; continue; } }
    split_comment(scan_line, lang, st, code, comment);
    if (lang & (CODE | KB)) apply_rules(c, code, ln, scan_line);
    scan_generic(c, scan_line, ln);
    if (lang & OTHER) apply_rules(c, scan_line, ln, scan_line);   // generic persistence rules apply to text/config too
    else if (lang & CFG) apply_rules(c, code, ln, scan_line);
  }
  if (c.decode_line && c.exec_line)
    c.add("decode-and-exec", "obfuscation", "backdoor", "decode-and-execute pattern", S::High, c.exec_line,
          "(decoder on line " + std::to_string(c.decode_line) + ", execution on line " + std::to_string(c.exec_line) + ")",
          "content is decoded and then executed: the classic way to hide a payload", .7, .3);
  if (c.plugin_refs > 200) c.rep.limitations.push_back(c.file + ": " + std::to_string(c.plugin_refs) + " plugin references (first 200 listed)");
  if (c.blobs && (lang & RPP)) c.add("rpp-state-blob", "inventory", "other", "embedded plugin state blobs", S::Info, 0, "(" + std::to_string(c.blobs) + " base64 lines)", "plugin state is stored as opaque base64; its contents are NOT analyzed", .8, .2);
}
void parse_baseline(const std::string& path, std::map<std::string, std::string>& out, std::string& err) {
  std::ifstream f(path);
  if (!f) { err = "cannot open baseline file: " + path; return; }
  std::string line; std::size_t n = 0;
  while (std::getline(f, line)) {
    ++n; if (!line.empty() && line.back() == '\r') line.pop_back();
    if (line.empty() || line[0] == '#') continue;
    if (line.size() < 67 || line[64] != ' ') { err = "baseline line " + std::to_string(n) + " is not '<sha256>  <path>'"; return; }
    for (int i = 0; i < 64; ++i) if (!std::isxdigit(static_cast<unsigned char>(line[static_cast<std::size_t>(i)]))) { err = "baseline line " + std::to_string(n) + ": bad hash"; return; }
    std::string p = line.substr(65); if (!p.empty() && (p[0] == ' ' || p[0] == '*')) p = p.substr(1);
    while (p.rfind("./", 0) == 0) p = p.substr(2);
    out[p] = lower(line.substr(0, 64));
  }
}
}  // namespace

std::size_t Report::count(Severity s) const { std::size_t n = 0; for (auto& f : findings) if (f.severity == s) ++n; return n; }
Severity Report::worst() const { Severity w = Severity::Info; for (auto& f : findings) if (f.severity > w) w = f.severity; return w; }

std::string detect_language(const std::string& filename, const std::string& first_line) {
  const std::string n = lower(fs::path(filename).filename().string());
  const std::string ext = lower(fs::path(filename).extension().string());
  if (n == "reaper-kb.ini") return "reaper-actions";
  if (ext == ".rpp" || ext == ".rpp-bak" || ext == ".rpp-undo") return "reaper-project";
  static const std::map<std::string, std::string> m = {{".py", "python"}, {".pyw", "python"}, {".pyi", "python"}, {".lua", "lua"}, {".eel", "eel"}, {".jsfx", "jsfx"},
    {".sh", "shell"}, {".bash", "shell"}, {".zsh", "shell"}, {".ksh", "shell"}, {".bat", "batch"}, {".cmd", "batch"}, {".ps1", "powershell"}, {".psm1", "powershell"},
    {".js", "javascript"}, {".mjs", "javascript"}, {".cjs", "javascript"}, {".ts", "javascript"}, {".c", "c/c++"}, {".h", "c/c++"}, {".cpp", "c/c++"}, {".hpp", "c/c++"},
    {".cc", "c/c++"}, {".cxx", "c/c++"}, {".hxx", "c/c++"}, {".m", "c/c++"}, {".mm", "c/c++"}, {".ini", "config"}, {".cfg", "config"}, {".conf", "config"},
    {".json", "config"}, {".yaml", "config"}, {".yml", "config"}, {".toml", "config"}, {".xml", "config"}, {".plist", "config"}, {".cmake", "config"},
    {".txt", "text"}, {".md", "text"}, {".rst", "text"}};
  auto it = m.find(ext); if (it != m.end()) return it->second;
  if (n == "makefile" || n == "dockerfile") return "shell";
  if (first_line.rfind("#!", 0) == 0) {
    const std::string l = lower(first_line);
    if (l.find("python") != std::string::npos) return "python";
    if (l.find("lua") != std::string::npos) return "lua";
    if (l.find("node") != std::string::npos) return "javascript";
    if (l.find("pwsh") != std::string::npos || l.find("powershell") != std::string::npos) return "powershell";
    if (l.find("sh") != std::string::npos) return "shell";
  }
  if (lower(first_line).rfind("desc:", 0) == 0) return "jsfx";
  return "text";
}

Report scan_text(const std::string& name, const std::string& text, const Options& opt) {
  Report rep;
  std::string first = text.substr(0, text.find('\n'));
  Ctx c{opt, name, lang_bit(detect_language(name, first)), rep};
  FileInfo fi; fi.path = name; fi.language = detect_language(name, first); fi.bytes = text.size(); fi.scanned = true;
  fi.sha256 = fk::hash::sha256_hex(reinterpret_cast<const unsigned char*>(text.data()), text.size());
  rep.files.push_back(fi);
  bool utf16 = false; std::string body = strip_nuls_for_utf16(text, utf16);
  scan_content(c, body);
  rep.limitations = {"Pattern matching only: false positives and false negatives are expected, and deliberate obfuscation defeats it.",
                     "Nothing was executed, imported, extracted or fetched; URLs were not contacted."};
  return rep;
}

Result<Report> scan_path(const fs::path& root, const Options& opt) {
  using R = Result<Report>;
  std::error_code ec;
  const auto st = fs::symlink_status(root, ec);
  if (ec) return R::fail("cannot access " + root.string());
  if (fs::is_symlink(st)) return R::fail("refusing to scan through a symbolic link: " + root.string());
  Report rep;
  std::vector<fs::path> paths;
  if (fs::is_regular_file(st)) paths.push_back(root);
  else if (fs::is_directory(st)) {
    fs::recursive_directory_iterator it(root, fs::directory_options::skip_permission_denied, ec), end;
    if (ec) return R::fail("cannot read directory " + root.string());
    for (; it != end; it.increment(ec)) {
      if (ec) { ++rep.skipped; ec.clear(); continue; }
      if (it->is_symlink(ec)) { ++rep.skipped; ec.clear(); continue; }
      if (it.depth() >= opt.max_depth) { it.disable_recursion_pending(); }
      if (!it->is_regular_file(ec)) continue;
      if (paths.size() >= opt.max_files) { rep.limitations.push_back("file limit reached (" + std::to_string(opt.max_files) + "); remaining files were not scanned"); break; }
      paths.push_back(it->path());
    }
    std::sort(paths.begin(), paths.end());
  } else return R::fail("not a regular file or directory: " + root.string());

  std::map<std::string, std::string> base; bool have_base = false;
  if (!opt.baseline_path.empty()) {
    std::string err; parse_baseline(opt.baseline_path, base, err);
    if (!err.empty()) return R::fail(err);
    have_base = true; rep.baseline.used = true;
  }
  const bool single = fs::is_regular_file(st);
  std::set<std::string> seen_rel;
  for (const auto& p : paths) {
    std::string rel = single ? p.filename().generic_string() : fs::relative(p, root, ec).generic_string();
    FileInfo fi; fi.path = rel;
    auto size = fs::file_size(p, ec); fi.bytes = ec ? 0 : size; ec.clear();
    auto h = fk::hash::sha256_file(p); fi.sha256 = h ? *h : "";
    seen_rel.insert(rel);
    if (have_base) {
      auto b = base.find(rel);
      if (b == base.end()) rep.baseline.new_files.push_back(rel);
      else if (b->second != fi.sha256) rep.baseline.modified.push_back(rel);
    }
    if (fi.bytes > opt.max_file_bytes) { fi.language = "unknown"; fi.note = "larger than the scan limit: hashed, not scanned"; rep.files.push_back(fi); ++rep.skipped; continue; }
    std::ifstream f(p, std::ios::binary);
    if (!f) { fi.note = "cannot read: skipped"; rep.files.push_back(fi); ++rep.skipped; continue; }
    std::string raw((std::istreambuf_iterator<char>(f)), std::istreambuf_iterator<char>());
    bool changed = false; std::string text = strip_nuls_for_utf16(raw, changed);
    const bool binary = text.substr(0, 8192).find('\0') != std::string::npos;
    Ctx c{opt, rel, 0, rep};
    if (binary) {
      const std::string kind = magic_kind(raw);
      fi.language = "binary: " + kind; fi.note = "hashed; contents not analyzed";
      const std::string ext = lower(p.extension().string());
      static const std::set<std::string> plug = {".dll", ".so", ".dylib", ".vst3", ".vst", ".clap", ".component", ".aaxplugin", ".node", ".exe"};
      if (kind.find("executable") != std::string::npos || kind.find("DLL") != std::string::npos) {
        if (plug.count(ext)) c.add("native-plugin-binary", "inventory", "unauthorized_plugin", "native code file: " + kind, S::Medium, 0, rel, "compiled code is not analyzed here; confirm it is on the plugin allowlist and verify its hash/signature", .6, .4);
        else c.add("native-binary", "inventory", "other", "native code file: " + kind, S::Low, 0, rel, "compiled code is not analyzed here", .5, .5);
      } else if (kind.find("archive") != std::string::npos)
        c.add("archive-not-opened", "inventory", "other", "archive not opened: " + kind, S::Low, 0, rel, "contents were not inspected; extract it into an isolated folder and scan that", .5, .5);
      rep.files.push_back(fi); continue;
    }
    const std::string first = text.substr(0, text.find('\n'));
    fi.language = detect_language(rel, first); fi.scanned = true; c.lang = lang_bit(fi.language);
    if (changed) fi.note = "UTF-16 detected; scanned as its ASCII subset";
    if (lower(fs::path(rel).filename().string()).rfind("__startup.", 0) == 0)
      c.add("reaper-startup-script", "persistence", "reascript_risk", "startup script", S::Medium, 0, rel, "name suggests it runs when REAPER starts (verify against your REAPER version)", .5, .5);
    scan_content(c, text);
    rep.files.push_back(fi);
  }
  if (have_base) for (auto& kv : base) if (!seen_rel.count(kv.first) && !single) rep.baseline.missing.push_back(kv.first);
  if (have_base) {
    for (auto& m : rep.baseline.modified) { Finding f; f.rule = "baseline-modified"; f.topic = "integrity"; f.category = "altered_code"; f.title = "file differs from baseline"; f.file = m; f.severity = Severity::High; f.evidence = "SHA-256 mismatch"; f.why = "the hash is certain; whether the change is malicious is not"; f.confidence = 0.95; f.false_positive = 0.05; rep.findings.push_back(f); }
    for (auto& m : rep.baseline.new_files) { Finding f; f.rule = "baseline-new"; f.topic = "integrity"; f.category = "altered_code"; f.title = "file not in baseline"; f.file = m; f.severity = Severity::Medium; f.evidence = "new file"; f.why = "not part of the reviewed baseline"; f.confidence = 0.9; f.false_positive = 0.2; rep.findings.push_back(f); }
    for (auto& m : rep.baseline.missing) { Finding f; f.rule = "baseline-missing"; f.topic = "integrity"; f.category = "altered_code"; f.title = "baseline file is missing"; f.file = m; f.severity = Severity::Medium; f.evidence = "missing"; f.why = "listed in the baseline but not found"; f.confidence = 0.9; f.false_positive = 0.2; rep.findings.push_back(f); }
  }
  for (const char* l : {"Pattern matching only: false positives and false negatives are expected, and deliberate obfuscation defeats it.",
                        "Nothing was executed, imported, extracted or fetched; URLs were not contacted; symbolic links were skipped, not followed.",
                        "Compiled binaries and archives are hashed and listed but their contents are not analyzed.",
                        "Absence of findings is not evidence that a script is safe."})
    rep.limitations.push_back(l);
  return R::success(std::move(rep));
}

namespace {
std::string jstr(const std::string& s) {
  std::string o = "\"";
  for (unsigned char c : s) {
    switch (c) { case '"': o += "\\\""; break; case '\\': o += "\\\\"; break; case '\n': o += "\\n"; break; case '\r': o += "\\r"; break; case '\t': o += "\\t"; break;
      default: if (c < 32) { char b[8]; std::snprintf(b, sizeof b, "\\u%04x", c); o += b; } else o.push_back(static_cast<char>(c)); }
  }
  return o + "\"";
}
std::vector<const Finding*> sorted(const Report& r) {
  std::vector<const Finding*> v; for (auto& f : r.findings) v.push_back(&f);
  std::stable_sort(v.begin(), v.end(), [](const Finding* a, const Finding* b) { if (a->severity != b->severity) return a->severity > b->severity; if (a->file != b->file) return a->file < b->file; return a->line < b->line; });
  return v;
}
}  // namespace
std::string Report::to_text() const {
  std::ostringstream o;
  std::size_t scanned = 0; for (auto& f : files) if (f.scanned) ++scanned;
  o << "HUSH script scan (local, read-only)\nfiles: " << files.size() << " listed, " << scanned << " scanned, " << skipped << " skipped\n";
  o << "findings: critical=" << count(Severity::Critical) << " high=" << count(Severity::High) << " medium=" << count(Severity::Medium)
    << " low=" << count(Severity::Low) << " info=" << count(Severity::Info) << "\n";
  if (baseline.used) o << "baseline: modified=" << baseline.modified.size() << " new=" << baseline.new_files.size() << " missing=" << baseline.missing.size() << "\n";
  o << "\n";
  std::size_t shown = 0;
  for (auto* f : sorted(*this)) {
    if (++shown > 1000) { o << "... (" << findings.size() - 1000 << " more findings; use --json for the full list)\n"; break; }
    o << "[" << severity_name(f->severity) << "] " << f->file; if (f->line) o << ":" << f->line;
    o << "  " << f->title << "  (" << f->rule << ", confidence " << f->confidence << ", false-positive " << f->false_positive << ")\n";
    if (!f->evidence.empty()) o << "      " << f->evidence << "\n";
    o << "      why: " << f->why << "\n";
  }
  if (findings.empty()) o << "no findings (this is not proof that the files are safe)\n";
  o << "\nLimitations:\n"; for (auto& l : limitations) o << "  * " << l << "\n";
  return o.str();
}
std::string Report::to_json() const {
  std::ostringstream o;
  o << "{\n  \"tool\": \"hush script-scan\",\n  \"mode\": \"local-read-only\",\n  \"summary\": {\"files\": " << files.size() << ", \"skipped\": " << skipped
    << ", \"critical\": " << count(Severity::Critical) << ", \"high\": " << count(Severity::High) << ", \"medium\": " << count(Severity::Medium)
    << ", \"low\": " << count(Severity::Low) << ", \"info\": " << count(Severity::Info) << "},\n  \"files\": [";
  for (std::size_t i = 0; i < files.size(); ++i) {
    auto& f = files[i];
    o << (i ? ",\n    " : "\n    ") << "{\"path\": " << jstr(f.path) << ", \"language\": " << jstr(f.language) << ", \"bytes\": " << f.bytes << ", \"sha256\": " << jstr(f.sha256)
      << ", \"scanned\": " << (f.scanned ? "true" : "false") << ", \"note\": " << jstr(f.note) << "}";
  }
  o << "\n  ],\n  \"findings\": [";
  std::size_t i = 0;
  for (auto* f : sorted(*this)) {
    o << (i++ ? ",\n    " : "\n    ") << "{\"id\": " << jstr(f->rule) << ", \"category\": " << jstr(f->category) << ", \"topic\": " << jstr(f->topic) << ", \"title\": " << jstr(f->title)
      << ", \"severity\": " << jstr(severity_name(f->severity)) << ", \"confidence\": " << f->confidence << ", \"false_positive_likelihood\": " << f->false_positive
      << ", \"location\": {\"file\": " << jstr(f->file) << ", \"line\": " << f->line << "}, \"evidence\": " << jstr(f->evidence) << ", \"why\": " << jstr(f->why) << "}";
  }
  auto arr = [&](const std::vector<std::string>& v) { std::string s = "["; for (std::size_t k = 0; k < v.size(); ++k) s += (k ? ", " : "") + jstr(v[k]); return s + "]"; };
  o << "\n  ],\n  \"integrity\": {\"baseline_used\": " << (baseline.used ? "true" : "false") << ", \"modified_files\": " << arr(baseline.modified)
    << ", \"new_files\": " << arr(baseline.new_files) << ", \"deleted_files\": " << arr(baseline.missing) << "},\n  \"limitations\": " << arr(limitations)
    << ",\n  \"requires_human_review\": true\n}\n";
  return o.str();
}
}  // namespace fk::scan
