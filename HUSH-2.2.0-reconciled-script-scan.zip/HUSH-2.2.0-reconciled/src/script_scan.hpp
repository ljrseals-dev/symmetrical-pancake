#pragma once
// fk::scan: local, read-only static scanner for scripts and project files (Python, Lua, EEL, JSFX, shell, batch,
// PowerShell, JavaScript, C/C++, REAPER .RPP / reaper-kb.ini, config files). It never executes, imports, extracts or
// fetches anything it reads, and makes no network calls. Findings are INDICATORS: a pattern scanner has false
// positives and false negatives, and deliberate obfuscation defeats it.
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <string>
#include <vector>
#include "result.hpp"
namespace fk::scan {
enum class Severity { Info, Low, Medium, High, Critical };
const char* severity_name(Severity s);
struct Finding {
  std::string rule, topic, category, title, file, evidence, why;
  Severity severity = Severity::Info;
  std::size_t line = 0;          // 1-based; 0 = whole file
  double confidence = 0.5, false_positive = 0.5;
};
struct FileInfo { std::string path, language, sha256; std::uint64_t bytes = 0; bool scanned = false; std::string note; };
struct BaselineResult { bool used = false; std::vector<std::string> modified, new_files, missing; };
struct Options {
  std::size_t max_file_bytes = 5u << 20;   // larger files are hashed but not scanned
  std::size_t max_files = 5000;
  int max_depth = 8;
  std::vector<std::string> allow_hosts;    // URLs to these hosts (or their subdomains) are not reported
  std::string baseline_path;               // sha256sum-format file; reports modified / new / missing files
};
struct Report {
  std::vector<FileInfo> files;
  std::vector<Finding> findings;
  BaselineResult baseline;
  std::vector<std::string> limitations;
  std::size_t skipped = 0;
  std::size_t count(Severity s) const;
  Severity worst() const;                  // Info when there are no findings
  std::string to_text() const;
  std::string to_json() const;
};
std::string detect_language(const std::string& filename, const std::string& first_line);
// Scan one in-memory text (used by tests and for pasted scripts).
Report scan_text(const std::string& name, const std::string& text, const Options& opt = {});
// Scan a file or a directory tree. Symbolic links are skipped, never followed.
Result<Report> scan_path(const std::filesystem::path& root, const Options& opt = {});
}  // namespace fk::scan
